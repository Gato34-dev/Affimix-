# AffiMix — site files

A static 4-page site: `index.html` (home + picks + feedback), `about.html`,
`privacy-policy.html`, `affiliate-disclosure.html`. Shared styles in
`css/style.css`, shared behavior in `js/main.js`.

## Add your affiliate links

Open `index.html` and find the product cards (search for `data-affiliate-slot`).
Each card has:

```html
<div class="card-thumb">Product image</div>
<h3>[Placeholder: Product name]</h3>
<p>One or two lines on why it earned a spot...</p>
<span class="price">from $[price]</span>
<a href="#" class="btn btn-primary btn-sm" data-affiliate-slot="tech-1" ...>Check price ↗</a>
```

Replace `[Placeholder: Product name]`, the price, and swap `href="#"` for your
real affiliate URL. The `rel="sponsored noopener noreferrer"` on those links is
intentional — `sponsored` tells search engines it's a paid/affiliate link
(good for SEO compliance with Google's guidelines), `noopener noreferrer` is a
security best practice for links that open in a new tab.

Swap the `card-thumb` div for a real `<img>` tag once you have product photos
— keep `loading="lazy"` on any image you add below the fold.

## About the "DDoS-proof" request

There's no such thing as a DDoS-proof file — protection against that lives at
the network/hosting layer, not in HTML/CSS/JS. What this build does to make
that protection easy and cheap:

- **Fully static.** No database, no server-side code to overload or exploit.
  Static files are the cheapest possible thing to serve at scale.
- **No third-party form backend.** The feedback bar uses `mailto:` instead of
  posting to a server you'd have to secure and rate-limit yourself.

To actually get DDoS protection, put the site behind a provider that offers it
at the network edge:

- **Cloudflare** (free tier) in front of any host — this is the standard,
  effectively free way to get real DDoS mitigation, a CDN cache, and free
  HTTPS.
- Or host directly on a platform with this built in: **Netlify**, **Vercel**,
  **GitHub Pages**, or **Cloudflare Pages** all serve static sites from a CDN
  with volumetric attack protection included.

## Deploying

Any static host works. Quickest options:

1. **Cloudflare Pages / Netlify / Vercel** — drag-and-drop this folder in
   their dashboard, or connect a GitHub repo for auto-deploys.
2. Point `affimix.com`'s DNS at whichever host you pick, and enable free
   HTTPS (all of the above do this automatically).
3. If you don't put Cloudflare in front by default, add it afterward — it's a
   DNS change, not a rebuild.

## SEO already wired in

- Per-page `<title>`, meta description, canonical URL, and Open Graph tags
- `robots.txt` and `sitemap.xml` (update the domain in both if it changes)
- Semantic HTML (`<nav>`, `<main>`, `<footer>`, one `<h1>` per page)
- `WebSite` structured data (JSON-LD) on the homepage
- No render-blocking heavy JS; fonts load via `<link>`, not `@import`

## Feedback bar

Visitors rate 1–5, enter their email (required, so you can reply directly),
and leave a note. Submitting opens their email app with a prefilled message
to `borriscollins227@gmail.com`, with their address included both in the body
and as the mailto `reply-to`, so hitting Reply on your end goes back to them.
Nothing is stored on the site itself — no database, no cookies, no
localStorage. If you'd rather visitors submit silently in-page (no email app
popup), swap the form's submit handler in `js/main.js` for a POST to a form
service like Formspree — that requires signing up for an account and
dropping in an endpoint URL.
